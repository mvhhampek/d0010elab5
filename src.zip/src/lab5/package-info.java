/**
 * Package to store all components of the lab,
 * as well as programs to run and to optimize the simulation
 * 
 * @author Hampus Kämppi, Gustav Edner, Jonathan Junel, Linus Karlsson
 */
package lab5;
