/**
 * Package containing specific classes for the store simulation
 * 
 * @author Hampus Kämppi, Gustav Edner, Jonathan Junel, Linus Karlsson
 */
package lab5.store;
