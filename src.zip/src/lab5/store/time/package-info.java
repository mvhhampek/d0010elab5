/**
 * Package containing randomly generated times for the stores specific events
 * 
 * @author Hampus Kämppi, Gustav Edner, Jonathan Junel, Linus Karlsson
 */
package lab5.store.time;