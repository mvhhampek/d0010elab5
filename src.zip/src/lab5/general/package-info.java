/**
 * Package containing general classes for a simulation
 * 
 * @author Hampus Kämppi, Gustav Edner, Jonathan Junel, Linus Karlsson
 */
package lab5.general;